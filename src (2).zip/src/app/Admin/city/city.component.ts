import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CityService } from 'src/app/services/City/city.service';
import { CityModel } from 'src/app/services/City/CityModel';


@Component({
  selector: 'app-city',
  templateUrl: './city.component.html',
  styleUrls: ['./city.component.scss']
})
export class CityComponent implements OnInit {


  formValue !: FormGroup
  CityData: any;
  CitysId: any = 0;
  countryName='';
  countrydata:any;
  CountryModelobj: CityModel = new CityModel();

  constructor(private formbuilder: FormBuilder, private api: CityService) { }

  ngOnInit(): void {

    this.formValue = this.formbuilder.group({
      cityId: [''],
      cityName: [''],
      countryRefId: [],
    })
    this.api.getCountries().subscribe((res: any) => {
      this.CityData = res;
      console.log(this.CityData);
    })

    this.api.getCo().subscribe((res: any) => {
      this.countrydata = res;
      console.log(this.countrydata);
    })
    
  }


  // this.api.getCountries().subscribe
  // (data => { this.CityData = data })
  // Add Country Record ******************************************************************************************

  postCityDetails() {
    this.CountryModelobj.cityName = this.formValue.value.cityName;
    this.CountryModelobj.countryRefId = this.formValue.value.countryRefId.countryId;


    this.api.postCountry(this.CountryModelobj)
      .subscribe(res => {
        console.log(res);
        alert("New Country added successfully");
        let ref = document.getElementById('cancel');
        ref?.click();
        this.formValue.reset();
        this.ngOnInit();
      },
        err => {
          alert("something went wrong")
        })
  }




  // postCityDetails() {
  //   this.api.postCountry(this.CountryModelobj)
  //   .subscribe({
  //     next:(country) => {
  //       alert("New Country added successfully");
    
  //     }

  //   })

  // }

  // Update Country Record ***************************************************************************************

  updateCountryDetails() {
    this.CountryModelobj.cityId = this.CitysId;
    this.CountryModelobj.cityName = this.formValue.value.cityName;
    this.CountryModelobj.countryRefId = this.formValue.value.countryRefId;

    alert("Update Record : " + this.CitysId);
    this.api.updateCountry(this.CountryModelobj, this.CitysId)
      .subscribe(res => {
        console.log(res);
        alert("Country update successfully");
        let ref = document.getElementById('cancel');
        ref?.click();
        this.formValue.reset();
        this.ngOnInit();
      }
      )
  }

  // Delete Country Record ***************************************************************************************

  deleteCountryDeatils(row: any) {
    alert("Delete Record : "+row.cityId);
    this.api.deleteCountry(row.cityId)
      .subscribe(res => {
        alert('Country record delete successfully');
        this.ngOnInit();
      })
  }

  

  GetByCountryID(row: CityModel) {
    this.CitysId = row.cityId;
    this.formValue.controls['cityName'].setValue(row.cityName);
    this.formValue.controls['countryRefId'].setValue(row.countryRefId);

  }

}
