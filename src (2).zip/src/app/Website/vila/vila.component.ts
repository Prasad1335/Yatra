import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vila',
  templateUrl: './vila.component.html',
  styleUrls: ['./vila.component.scss']
})
export class VilaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
