import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-master-navbar',
  templateUrl: './master-navbar.component.html',
  styleUrls: ['./master-navbar.component.css']
})
export class MasterNavbarComponent implements OnInit {
   page:any;
 constructor() {
   // var admin = 'app-master-navbar';
    var user = 'app-wesiteb-navigation-bar';
    if(window.location.href.includes(user))
      this.page="user";
  //  else
  //     this.page="user";
  }

  ngOnInit(): void {
  }

}
