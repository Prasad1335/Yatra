export class AirlineModel{
    airlineId: number=0;
    airlineName: string='';
    airlineShortName: string='';
    airlineLogo: string='';
    airlineAddress: string='';
    cityRefId:number=0;
    airlinePinCode: string='';
    airlineTelephone1: number=0;
    airlineTelephone2: number=0;
    airlineEmail1: string='';
    airlineEmail2: string='';
  }