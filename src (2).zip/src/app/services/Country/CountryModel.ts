
export class CountryModel {
    countryId: number = 0;
    countryCode: string = '';
    countryName: string = '';
    countryShortName: string = '';

}