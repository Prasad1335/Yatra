export class CustomerModel {

    customerId: number = 0;
    customerFirstName: string = '';
    customerLastName: string = '';
    customerDateOfBirth:string='';
    customerAddress1: string = '';
    customerAddress2: string = '';
    cityRefId: number = 0;
    customerPinCode: string = '';
    customerTelephone: number = 0;
    customerEmail: string = '';

}

