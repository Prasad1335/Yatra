export class FlightModel{
 
       flightId:number= 0;
       flightCode:string='';
       airlineRefId:number= 0;
       fromAirportRefId:number= 0;
       toAirportRefId:number= 0;
        
        }
