export class FlightScheduleModel {
    flightScheduleId: number = 0;
    flightRefId: number = 0;
    departureDateTime: string = '';
    arrivalDateTime: string = '';
}