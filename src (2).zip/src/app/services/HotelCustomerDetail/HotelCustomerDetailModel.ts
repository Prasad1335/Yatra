export class HotelCustomerDetailModel {
    hotelCustomerDetailId: number = 0;
    hotelBookingRefId: number = 0;
    customerRefId: number = 0;
}


