import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wesiteb-navigation-bar',
  templateUrl: './wesiteb-navigation-bar.component.html',
  styleUrls: ['./wesiteb-navigation-bar.component.scss']
})
export class WesitebNavigationBarComponent implements OnInit {

  // page:any;
  constructor() {
  // var admin = 'app-master-navbar';
    //  var user = 'app-wesiteb-navigation-bar';
    //  if(window.location.href.includes(user))
    //   this.page="user";
    //  else
    //    this.page="admin";
  }

  ngOnInit(): void {
  }

}
