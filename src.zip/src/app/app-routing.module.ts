import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AirlineComponent } from './Admin/airline/airline.component';
import { AirportComponent } from './Admin/airport/airport.component';
import { AmenitiesComponent } from './Admin/amenities/amenities.component';
import { CityComponent } from './Admin/city/city.component';
import { CountryComponentComponent } from './Admin/country/country-component.component';
import { CustomerComponent } from './Admin/customer/customer.component';
import { FlightBookingComponent } from './Admin/flight-booking/flight-booking.component';
import { FlightCustomerDetailComponent } from './Admin/flight-customer-detail/flight-customer-detail.component';
import { FlightScheduleComponent } from './Admin/flight-schedule/flight-schedule.component';
import { FlightComponent } from './Admin/flight/flight.component';
import { HotelAmenitiesLinkComponent } from './Admin/hotel-amenities-link/hotel-amenities-link.component';
import { HotelBookingComponent } from './Admin/hotel-booking/hotel-booking.component';
import { HotelCustomerDetailComponent } from './Admin/hotel-customer-detail/hotel-customer-detail.component';
import { HotelComponent } from './Admin/hotel/hotel.component';
import { LoginAdminComponent } from './login-admin/login-admin.component';
import { MasterNavbarComponent } from './master-navbar/master-navbar.component';
import { FlightSearchComponent } from './Website/flight-search/flight-search.component';
import { HotelSearchComponent } from './Website/hotel-search/hotel-search.component';
import { HotelWebPageComponent } from './Website/hotel-web-page/hotel-web-page.component';
import { WebFlightPageComponent } from './Website/web-flight-page/web-flight-page.component';


const routes: Routes = [
  // common component navaigation routing*******************************
  { path: 'app-login-admin', component: LoginAdminComponent },
  { path: 'app-master-navbar', component: MasterNavbarComponent },

  { path: 'app-customer', component: CustomerComponent },
  { path: 'app-country-component', component: CountryComponentComponent },
  { path: 'app-city', component: CityComponent },

  // // hotel navaigation routing******************************************

  { path: 'app-hotel', component: HotelComponent },
  { path: 'app-amenities', component: AmenitiesComponent },
  { path: 'app-hotel-amenities-link', component: HotelAmenitiesLinkComponent },
  { path: 'app-hotel-booking', component: HotelBookingComponent },
  { path: 'app-hotel-customer-detail', component: HotelCustomerDetailComponent },

  // // Flight navaigation routing*******************************************
  { path: 'app-airline', component: AirlineComponent },
  { path: 'app-airport', component: AirportComponent },
  { path: 'app-flight', component: FlightComponent },
  { path: 'app-flight-schedule', component: FlightScheduleComponent },
  { path: 'app-flight-booiking', component: FlightBookingComponent },
  { path: 'app-flight-customer-detail', component: FlightCustomerDetailComponent },


  //********************************************************************************************
  //********************************************************************************************
  { path: 'app-web-flight-page', component: WebFlightPageComponent },
  { path: 'app-flight-search', component: FlightSearchComponent },
  
  { path: 'app-hotel-web-page', component: HotelWebPageComponent },
  { path: 'app-hotel-search', component: HotelSearchComponent }






];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
