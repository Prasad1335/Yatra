export class AirportModel{
   airportId:number=0;
   airportCode:string='';
   airportName:string='';
   airportAddress:string='';
   cityRefId:number=0;
   airportPinCode:string='';
   airportTelephone1:number=0;
   airportTelephone2:number=0;
   airportEmail1:string='';
   airportEmail2:string='';
  }
