export class AmenitiesModel {
    amenitiesId: number = 0;
    amenitiesName: string = '';
    amenitiesDescription: string = '';
}




