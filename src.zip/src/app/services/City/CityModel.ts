import { CountryModel } from "../Country/CountryModel";

export class CityModel {
    cityId: number = 0;
    cityName: string = '';
    countryRefId: number = 0;


}