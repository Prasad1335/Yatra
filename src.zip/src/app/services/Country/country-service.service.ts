import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { map, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CountryServiceService {

  constructor(private http: HttpClient) { }

  BaseUrl: string = 'https://localhost:7204/api/Countries';

  // Get All Countries Record *************************************************************
 getCountries() {
    return this.http.get<any>(this.BaseUrl)
      .pipe(map((res: any) => {
        return res;
      }))
  }


  // Add Country Record *********************************************************************

  postCountry(data: any) {
    return this.http.post<any>(this.BaseUrl, data)
      .pipe(map((res: any) => {
        return res;
      }))
  }

  // postCountry(data: any):Observable<any> {
  //   return this.http.get(this.BaseUrl,data);
  // }

  // Update Country Record *******************************************************************

  updateCountry(data: any, id: number) {
    return this.http.put<any>(`${this.BaseUrl}/${id}`, data)
      .pipe(map((res: any) => {
        return res;
      }))
  }


  // Delete Country Record *******************************************************************
  deleteCountry(id: number) {
    return this.http.delete<any>(`${this.BaseUrl}/${id}`)
      .pipe(map((res: any) => {
        return res;
      }))
  }

}


