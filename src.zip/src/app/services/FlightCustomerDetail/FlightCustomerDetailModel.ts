export class FlightCustomerDetailModel {
    flightCustomerDetailId: number = 0;
    flightBookingRefId: number = 0;
    customerRefId: number = 0;
}


