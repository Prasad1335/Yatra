export class HotelModel {

    hotelId: number = 0;
    hotelName: string = '';
    hotelStar: number = 0;
    cityRefId: number = 0;

}

