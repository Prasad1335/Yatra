export class HotelAmenitiesLinkModel {
    hotelAmenitiesLinkId:number= 0;
    hotelRefId:number= 0;
    amenitiesRefId:number= 0;
}